document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', e => {
      e.preventDefault();
      const targetId = link.getAttribute('href').slice(1);
      const targetElement = document.getElementById(targetId);
      if (targetElement) {
          window.scrollTo({
              top: targetElement.offsetTop - 60,
              behavior: 'smooth',
          });
      }
  });
});
